public void class LogicalSentance {
  // stub class
}
