public class Main {
  public static void main(String[] args){
    CowFrame philippe = new CowFrame();
    philippe.setDefaultCloseOperation(philippe.EXIT_ON_CLOSE);
    philippe.setVisible(true);
  }
}
