# State Updater

When run, this project takes input values for position, velocity, acceleration, and time to calculate a final position.

### Errors

Had to figure out how to deal with dimension input above 3 or below 0.

### Code Overview

Main.java basically just creates an instance of StateUpdater.java and runs calculatePosition.
StateUpdater.java basically just asks for values and moves calculated values around with double[]s.

### Major Challenges

Biggest challenge was to make more recursive (as opposed to just infinite print scan repeat).

### Acknowledgments

actually did this one all by myself... yay me...

## Built With

atom, java, some libraries and stuff
