public class Main {
  public static void main(String[] args){
    FlagFrame usFlag = new FlagFrame();
    usFlag.setVisible(true);
    usFlag.updateFrameSize();
  }
}
