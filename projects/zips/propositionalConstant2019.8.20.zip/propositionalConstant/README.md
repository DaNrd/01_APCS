# Testing a Propositional Constant

This project contains the 4 requested classes.

### Errors

There are no errors (I think).

### Code Overview

ProportionalConstant.java contains 2 methods. "name" takes no arguments and returns a string ("" by default), and "truthValue" takes no arguments and returns a boolean (true by default).

TestProportionalConstant.java has a main method that creates a new instance of ProportionalConstant called ProportionalConstant01 and prints the name and truth value.

TruthAssignment.java and LogicalSentance.java are stub classes (exists but doesn't do anything when called).

### Major Challenges

I didn't know what a stub class was but figured it out. Also my syntax knowledge is pretty basic so I kept having to fix errors.

### Acknowledgments

Thanks to Ben for help with stub classes and Quintin for a refresher on syntax.

## Built With

N/A
