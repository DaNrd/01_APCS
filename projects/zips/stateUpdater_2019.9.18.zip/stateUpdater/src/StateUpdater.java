import java.lang.*;
import java.util.*;

public class StateUpdater{
	public void calculatePosition(){
		System.out.println("In how many dimensions is your motion?");
		Scanner dimensionScanner = new Scanner(System.in);
		int d = (int)Double.parseDouble(dimensionScanner.nextLine());
		double[] sva = findSVA(d);
		System.out.println("Please input the time:");
		Scanner tScanner = new Scanner(System.in);
		double t = Double.parseDouble(tScanner.nextLine());
		double[] orderedPair = calcFinal(sva, t);
		System.out.println("At t = " + t + " seconds, the particle's position will be at (" + orderedPair[0] + "," + orderedPair[1] + "," + orderedPair[2] +  ") meters.");
	}
	public double[] findSVA(int d){
		if(d>3){
			System.out.println(" ");System.out.println(" ");System.out.println(" ");System.out.println(" ");System.out.println("How?");
			calculatePosition();
		} else if(d<1){
			System.out.println(" ");System.out.println(" ");System.out.println(" ");System.out.println(" ");System.out.println("Hey... You can't do that!");
			calculatePosition();
		}
		double[] retval = new double[d*3];
		char[] dimensionChars = new char[]{'x','y','z'};
		for(int i = 0; i<d; i++){
				System.out.println("What is the original " + dimensionChars[i] + " position?");
				Scanner sScanner = new Scanner(System.in);
				retval[(3*i)] = Double.parseDouble(sScanner.nextLine());
				System.out.println("What is the velocity along the " + dimensionChars[i] + " axis?");
				Scanner vScanner = new Scanner(System.in);
				retval[(3*i)+1] = Double.parseDouble(vScanner.nextLine());
				System.out.println("What is the acceleration along the " + dimensionChars[i] + " axis?");
				Scanner aScanner = new Scanner(System.in);
				retval[(3*i)+2] = Double.parseDouble(aScanner.nextLine());
		}
		return retval;
	}
	public double[] calcFinal(double[] sva, double t){
		double[] retval = new double[3];
		for(int i = 0; i<sva.length/3; i++){
			retval[i] = sva[(3*i)] + (sva[(3*i)+1]*t) + (0.5*sva[(3*i)+2]*Math.pow(t,2));
		}
		return retval;
	}
}
