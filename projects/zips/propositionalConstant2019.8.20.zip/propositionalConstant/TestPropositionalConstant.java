public class TestProportionalConstant {
  public static void main() {
    ProportionConstant01 = new ProportionConstant();
    System.out.println(ProportionConstant01.name);
    System.out.println(ProportionConstant01.truthValue);
  }
}
