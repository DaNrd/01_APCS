public class PropositionalConstant {

  public String name() {
    return "";
  }

  public Boolean truthValue() {
    return true;
  }
}
